﻿namespace vignette_frontend.Models
{
    public class Report
    {
        public string Registration { get; set; }
        public string DateCreated { get; set; }
        public bool IsSuccess { get; set; }
    }
}
